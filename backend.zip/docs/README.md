 
# Title
 Reflex-Repo
# Description
 Template web-application project utilizing the Reflex framework, built in Python.
# Install
 1. Create a virtual environment:
   """ python3 -m venv .venv """
 2. Activate the environment:
   """ source .venv/bin/activate """
 3. Install dependencies:
   """ pip install -r requirements.txt """
 4. Run Reflex:
   """ reflex run """
# Usage
 Extensive portfolio / e-commerce web app using only Python and Reflex libraries.
# Contribution
 Working on getting the regex for the auth login, and the redirect.
 Contributions and suggestions are welcome.
# Testing
 TBD
# License
 undefined
# Usage
  Simple web app
# Github Username
 mdub187
# Email
 maweeks.91@gmail.com
#
