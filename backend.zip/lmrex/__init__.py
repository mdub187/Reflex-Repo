# Initializes the lmrex package
