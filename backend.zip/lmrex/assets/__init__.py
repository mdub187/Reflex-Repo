if __name__ == "__main__":
    print(__name__)
