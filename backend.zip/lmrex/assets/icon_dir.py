# ./lmrex/assets/icon_dir.py

ICON_MAP = {
    "behance": "social_icons/behance.png",
    "dropbox": "social_icons/dropbox.png",
    "facebook": "social_icons/facebook.png",
    "github": "social_icons/github.png",
    "instagram": "social_icons/instagram.png",
    "linkedin": "social_icons/linkedin.png",
    "reddit": "social_icons/reddit.png",
    "soundcloud": "social_icons/soundcloud.png",
    "spotify": "social_icons/spotify.png",
    "twitch": "social_icons/twitch.png",
    "vimeo": "social_icons/vimeo.png",
    "whatsapp": "social_icons/whatsapp.png",
    "youtube": "social_icons/youtube.png",
    "music-notes": "music-notes-minus-thin.svg",
}
