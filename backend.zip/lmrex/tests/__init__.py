if __name__ == "__main__":
    import pytest
    pytest.main()
